#ifndef EFF_H
#define EFF_H

#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <sys/time.h>
#include <inttypes.h>

void start_tests(FILE *f);

#endif
