#ifndef ERRS_H
#define ERRS_H

// Коды ошибок и размеры значений
#define ERR_OK 0
#define ERR_RANGE 1
#define ERR_MANTISS_SIZE 2
#define ARR_SIZE (MAX_MANTISS_SIZE * 2)
#define MAX_FIRST_MANTISS_SIZE 35
#define MAX_SECOND_MANTISS_SIZE 40
#define MAX_RESULT_MANTISS_SIZE 40
#define MAX_ORDER_SIZE 5
#define MAX_MANTISS_SIZE 40
#define BASE 10

#endif