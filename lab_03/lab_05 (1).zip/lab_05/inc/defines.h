#ifndef _DEFINES_H_
#define OVERFLOW 1
#define ALLOCATE 2
#define MAXLEN 1000
#define EPS 1e-9
#define _DEFINES_H_
#endif